# Stok Gudang (Android)

Aplikasi pencatat stok barang masuk dan keluar dengan **kode unik** per barang dan **nomor batch** per penerimaan.

## Fitur
- Master barang: kode unik (bisa dibuat otomatis), nama, satuan
- Barang masuk: kode barang + nomor batch + jumlah + tanggal kedaluwarsa (opsional) + catatan
- Barang keluar: pilih batch yang tersedia, stok tidak bisa minus
- Stok per barang (total) dan rincian per batch
- Riwayat semua transaksi (masuk/keluar) lengkap dengan batch dan waktu
- Data tersimpan offline di perangkat (Room/SQLite)

## Build lewat GitHub
1. Buat repository baru di GitHub, lalu upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions**, workflow **Build APK** berjalan otomatis (atau klik **Run workflow**).
3. Setelah selesai, buka run tersebut dan unduh artifact **StokGudang-debug-apk**.
4. Ekstrak zip, pindahkan `app-debug.apk` ke HP, lalu install (izinkan install dari sumber tidak dikenal).
